
<?php
    $dbuser="root";
    $dbpass="administrator";
    $host="localhost";
    $db="posci";
    $mysqli=new mysqli($host,$dbuser, $dbpass, $db);
?>